export const PLACEHOLDER = {
    to: "받는 사람의 이름을 입력해 주세요.",
    from: "이름을 입력해 주세요.",
  };     